package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductPage {
	private WebDriver driver;
	private WebDriverWait wait;
	
	public ProductPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }
	private By findOrestesFitnessShort = By.xpath("//a[contains(text(),'Orestes Fitness Short')]");
	private By findColorOptions = By.xpath("//div[@id='option-label-color-93-item-49']");
	private By findSizeOptions = By.xpath("//div[@id='option-label-size-143-item-177']");
	private By findAddToCartButton = By.xpath("//span[contains(text(),'Add to Cart')]");

	public void clickSearhedShortsButton() {
		driver.findElement(findOrestesFitnessShort).click();
	}
	public void selectColorOption() {
		driver.findElement(findColorOptions).click();
	}
	public void sekectSizeOption() {
		driver.findElement(findSizeOptions).click();
	}
	public void clickAddToCartButton() {
		driver.findElement(findAddToCartButton).click();
	}
}
