package config;

public class Config {
    public static final String BASE_URL = "https://magento.softwaretestingboard.com";
    public static final String DRIVER_PATH = "C:\\Users\\ASUS-PC\\Downloads\\chrome-win64\\chrome-win64\\chrome.exe";
}
